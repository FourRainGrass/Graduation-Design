package com.xiangmu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class Runboot {

	public static void main(String[] args) {
		SpringApplication.run(Runboot.class, args);

	}

}
