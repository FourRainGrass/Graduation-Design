package com.xiangmu.util;

public class Fujian
{
	private String fujian;
	private String fujianYuan;
	
	public String getFujian() {
		return fujian;
	}
	public void setFujian(String fujian) {
		this.fujian = fujian;
	}
	
	public String getFujianYuan() {
		return fujianYuan;
	}
	public void setFujianYuan(String fujianYuan) {
		this.fujianYuan = fujianYuan;
	}
	public Fujian(String fujian, String fujianYuan){
		this.fujian = fujian;
		this.fujianYuan = fujianYuan;
	}
	public Fujian(){
		
	}
	
}
