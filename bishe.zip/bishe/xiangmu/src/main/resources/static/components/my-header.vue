<template>
<div class="container" style="height: 33px;padding-left: 666px;padding-top: 5px;">
    <span v-if="!isLogin">
		 <span style="margin-left: 11px;"><a style="color: white" href="/view/user/userReg.html">用户注册</a></span>
		 <span style="margin-left: 11px;"><a style="color: white" href="/view/user/userLogin.html">登录</a></span>
    </span>
    <span v-else>
         <span style="margin-left: 11px;color: white">欢迎您：{{user.xingming}}</span>
         <span style="margin-left: 11px;"><a style="color: white" href="/auser/index.html">个人中心</a></span>
         <span style="margin-left: 11px;"><a style="color: white" href="javaScript:;"  @click="userLogout()">退出系统</a></span>
    </span>
</div>
</template>



<script>

    module.exports = {
        data: function() {
            return {
                isLogin: false,
            }
        },
        methods: {
            handeler() {
                //this.count = this.count + 1;
            },
            
            userLogout(){
               if(confirm('确实要退出吗?')){
                  sessionStorage.removeItem("user");
                  window.location.href="/index.html";
               }
               
            },
            
        },
        
        
        

        created()
        {
            var userJsonString = sessionStorage.getItem("user");
            if(userJsonString !=null)//判断是否登录
            {
                var user=JSON.parse(userJsonString);
                this.user=user;
                this.isLogin=true;
            }
            else
            {
                 this.isLogin=false;
            }

            
        },
        
        mounted() 
        {
            /* let script = document.createElement('script');
            script.type = 'text/javascript';
            script.src = 'js/comm.js';
            document.body.appendChild(script); */
        },

    }


</script>


<style>
   @import url();
</style>

