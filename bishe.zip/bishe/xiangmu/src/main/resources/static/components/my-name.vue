<template>
<span style="font-size: 26px;">基于Web的剧本杀预约与管理系统</span>
</template>
