<template>
<div style="padding-left: 58px;padding-top: 28px;">
				<ul class="nav">
					<li><a href="/index.html" style="font-size: 16px;padding-left: 52px;">首页首页</a></li>
					<li><a href="/view/gonggao/gonggaoAll.html" style="font-size: 16px;">系统公告</a></li>
					<li><a href="/view/fang/fangAll.html" style="font-size: 16px;">房间信息</a>
						<ul>
							<li v-for="(fang, index) in fangList" :key="index"><a :href="'/view/fang/fangDetailQian.html?id='+fang.id">{{fang.mingcheng}}</a></li>
							<!--<li><a href="products.html">Footwear</a></li>-->
						</ul>
					</li>
					<li><a href="/view/liuyanban/liuyanbanAll.html" style="font-size: 16px;padding-left: 22px;">系统留言板</a></li>
					<li><a href="/view/xinwen/xinwenAll.html" style="font-size: 16px;">新闻资讯</a></li>
				</ul>
</div>

</template>



<script>

    module.exports = {
        data: function() {
            return {
                fangList:[],
            }
        },
        methods: {
            handeler() {
                //this.count = this.count + 1;
            },
            
            fangAll()
			{
	           axios({
						method: 'POST',
						url: '/fangAll',
						/* data: this.laoshi, */
						/* params:{
							username:this.laoshi.userName,
							password:this.laoshi.userPw,
						} */
						}).then(data => {
							if (data.data.state == 66)
							{
								this.fangList=data.data.data;
								//alert(this.fangList.length);
							} 
						}).catch(error => {
							alert(error);
				})
			},
        },
        
        
        

        created()
        {
            this.fangAll();
        },
        
        mounted() 
        {
            let script = document.createElement('script');
            script.type = 'text/javascript';
            script.src = '/js/nav.js';
            document.body.appendChild(script); 
        },

    }


</script>


<style>
   @import url();
</style>

