<template>
<div class="copy">
		    <span style="color: white;">Copyright &copy; Company name All rights reserved</span>
		    <span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
		    <span style="color: white;"><a href="/login.html" style="color: white;">管理员登录</a></span>
</div>
</template>

<script>
    module.exports = {
        data: function() {
            return {
                msg: "",
            }
        },
        methods: {
            handeler() {
            }
        }
    }
</script>

<style>
   @import url();
</style>	
