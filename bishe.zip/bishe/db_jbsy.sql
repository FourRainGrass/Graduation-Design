/*
Navicat MySQL Data Transfer

Source Server         : localhost_3328
Source Server Version : 50732
Source Host           : localhost:3328
Source Database       : db_jbsy

Target Server Type    : MYSQL
Target Server Version : 50732
File Encoding         : 65001

Date: 2025-02-19 16:38:20
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `t_admin`
-- ----------------------------
DROP TABLE IF EXISTS `t_admin`;
CREATE TABLE `t_admin` (
  `id` int(11) NOT NULL,
  `username` varchar(66) DEFAULT NULL,
  `password` varchar(55) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_admin
-- ----------------------------
INSERT INTO `t_admin` VALUES ('1', 'a', 'a');

-- ----------------------------
-- Table structure for `t_fang`
-- ----------------------------
DROP TABLE IF EXISTS `t_fang`;
CREATE TABLE `t_fang` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mingcheng` varchar(200) DEFAULT NULL,
  `jieshao` varchar(3000) DEFAULT NULL,
  `fujian` varchar(255) DEFAULT NULL,
  `fujianYuan` varchar(255) DEFAULT NULL,
  `del` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_fang
-- ----------------------------
INSERT INTO `t_fang` VALUES ('34', '密室逃脱001房', '一场精心策划的密室逃脱游戏，玩家需要在有限的时间内，通过解谜、寻找线索，成功逃离密室', '/upload/4C4703FD-D58B-4CF4-BA37-A290ABA0DC13.png', '1.png', 'no');
INSERT INTO `t_fang` VALUES ('37', '密室逃脱002室', '一场精心策划的密室逃脱游戏，玩家需要在有限的时间内，通过解谜、寻找线索，成功逃离密室', '/upload/1E749761-3BB5-4187-A6E2-67A22581894C.png', '1.png', 'no');
INSERT INTO `t_fang` VALUES ('38', '死亡通知单003房', '以悬疑小说为背景，玩家将扮演私家侦探，调查一系列离奇案件。剧本中充满了谜题和伏笔，玩家需要运用自己的推理能力，揭开真相，找出凶手', '/upload/B7DE1D3C-4F50-4FE4-92A7-24CC92503B1F.png', '2.png', 'no');
INSERT INTO `t_fang` VALUES ('39', '暗杀名单004房', '玩家将扮演特工，执行一系列暗杀任务。剧本中融入了间谍、特工等元素，让玩家在紧张刺激的游戏氛围中，体验一把惊险刺激的特工生活', '/upload/AEB1BFD8-75CF-4301-8FE2-1CC22EC60038.png', '3.png', 'no');
INSERT INTO `t_fang` VALUES ('40', '时光旅人005房', '一场穿越时空的旅行，玩家将回到过去，改变自己的命运。剧本中融入了亲情、友情、爱情等元素，让玩家在游戏中感受到情感的温暖和力量。', '/upload/2F3D7B61-6ACE-46E7-872F-2C0A3522A38C.png', '5.png', 'no');

-- ----------------------------
-- Table structure for `t_gonggao`
-- ----------------------------
DROP TABLE IF EXISTS `t_gonggao`;
CREATE TABLE `t_gonggao` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `biaoti` varchar(200) DEFAULT NULL,
  `neirong` varchar(3000) DEFAULT NULL,
  `fujian` varchar(255) DEFAULT NULL,
  `fujianYuan` varchar(255) DEFAULT NULL,
  `shijian` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_gonggao
-- ----------------------------
INSERT INTO `t_gonggao` VALUES ('1', '潮声丨你有多久没玩过剧本杀了？', '可歌可泣的爱情、惊心动魄的解密、扑朔迷离的剧情......七八人围坐在一起，研读剧本，代入角色，推理分析，作为沉浸感十足的桌游，剧本杀一经问世便风靡全国，成为年轻人间炙手可热的游戏。\n然而近几年，剧本杀行业发展遇到了瓶颈。据线下剧本平台小黑探的数据显示，全国线下剧本杀游戏收入仅为1.8亿元，较去年同期锐减1.1亿元，“闭店流”在行业中不断涌现。\n剧本杀大起大落，问题出在哪里？冷静过后，又带给我们哪些启示？', '/upload/46100AC0-237D-420B-A0E2-9528F4650104.png', '1.png', '2025-02-14 18:23');
INSERT INTO `t_gonggao` VALUES ('2', '剧本杀《替罪羊》剧本杀复盘+破解迷雾+揭秘线索', '剧本杀是一种小众的角色扮演游戏，最初源自欧美流行的派对游戏LARP（Live Acting Role Playing Game）。玩家会拿到一个剧本，扮演其中一个角色，通过沟通寻找线索，最终找出凶手。\n了解剧本风格，匹配自身兴趣。例如，喜欢哭哭本的玩家就不要选择硬核本。不盲选，从口碑好的剧本开始，一定程度上过滤掉体验不佳的剧本。新手可以从欢乐本入手，欢乐的氛围更容易让人融入和沉浸。', '/upload/CDE61A38-A0FC-4CE6-9D1E-72F4D6EF6F8E.png', '2.png', '2025-02-14 18:23');
INSERT INTO `t_gonggao` VALUES ('3', '适合新手玩的剧本杀给你们整理出来了', '整理了十几个比较好的适合新手党入坑的剧本，其中有欢乐本、推理本、立意本、情感本、恐怖本，根据自己的喜欢选择一个去玩吧。\n新手开始打本，不要玩太难的也不要只玩哪一种类型，最重要的是入坑，可以每个类型都玩一下，慢慢玩得多了可以确定自己喜欢哪一类型，然后选择这一类型里面难一点的玩。', '/upload/50B7341F-D8B6-40A8-B27C-60BEA8BAA469.png', '3.png', '2025-02-14 18:25');
INSERT INTO `t_gonggao` VALUES ('4', '13个必玩剧本杀推荐，停不下来！', '最近两个月，我玩了13场剧本杀，跑了4家店。嗓子疼、姨妈痛，甚至带着病痛也在玩，不是在杀就是在去杀的路上。朋友们都以为我入股了剧本杀店，或者成了代言人。\n之前一直通过一个公主号和一群戏精同事在线下玩，直到2020年12月才第一次去剧本杀店，从此一发不可收拾。有DM和NPC的演绎，还有场景和道具，体验感真的不一样。以下是我按照玩本的时间顺序推荐的剧本杀，不断更新中：\n爱幼妇产医院 - 现代恐怖还原 - 奇幻\n是我们第一次线下玩剧本杀，女生们胆子小，所以选择了下午，也不那么吓人。黑羊公馆 - 还原 微恐 - 奇幻\n爆灯推荐！非常依赖DM和NPC的演绎，让我真正觉得剧本杀店有必要的一部作品。场景转换、多名NPC的演绎、DM的控场，让我们这群玩了快9小时的人，在结束之后的一两个月还能津津乐道，提到“迷途的羔羊”还能瑟瑟发抖。', '/upload/202D681F-C25A-4632-A8B5-D12CF5764A69.png', '4.png', '2025-02-14 18:26');
INSERT INTO `t_gonggao` VALUES ('5', '剧本杀新手入门指南', '新手第一次玩剧本杀，有哪些知识是一定要知道的，看这一篇就够啦！\n剧本杀介绍剧本杀源自英文名“MurderMystery”，是一种角色扮演游戏。一群玩家会扮演剧本中的不同角色，通过搜集线索、推理和讨论，找出隐藏在你们中间的“凶手”。Suspense is in the air!剧本杀人员配置剧本杀通常需要5人以上，越多越好玩。如果人数不够，可以问问店家是否有拼车服务哦。\n选择一个喜欢的本子，目前剧本杀剧本种类分为：情感本、欢乐本、阵营机制本、硬核推理本。', '/upload/C1184B41-5EBB-4A64-B023-70B3F4C151CC.png', '5.png', '2025-02-14 18:26');
INSERT INTO `t_gonggao` VALUES ('6', '剧本杀新手必看：从入门到精通全攻略', '剧本杀，简单来说，就是有剧本安排的狼人杀。它分为两大类：实景搜证（类似于密室逃脱）和桌面剧本杀（价格相对便宜）。剧本又可以分为三种类型：硬核本：适合喜欢烧脑的侦探游戏，没有过多的情感和互动环节，纯侦探游戏。<br />\n机制本：通过游戏互动、积分形式进行，推凶环节不太重要，重要的是游戏积分环节，如投镖、打副本等，最终达到积分最高或阵营分最高胜利。情感本：纯情感游戏，推凶不重要，重点是亲情、爱情的体验感。<br />\n每位玩家都会分配一个角色人设剧本，需要代入角色，根据角色人设和故事剧本，通过讨论、搜证等环节来盘凶，投票推凶手。', '/upload/AD1B8F92-E30A-4052-96D2-C9E973A357B3.png', '6.png', '2025-02-14 18:27');
INSERT INTO `t_gonggao` VALUES ('7', '剧本杀入坑体验分享', '年我从密室逃脱爱好者转变成了剧本杀的狂热爱好者。本着“菜且爱玩”的原则，我尝试了15本不同类型的剧本杀，包括推理、机制和阵营还原等，逐渐对这些类型的乐趣有了更深的了解。以下是我2023年的年度TOP3推荐：逃出迷雾镇\n这本盒装本难度适中，适合新手玩家体验。它不仅能给新手带来乐趣，也能让老玩家感受到不同的游戏体验，绝对值得一试！怪谈事务所破界\n这是我玩的第一个机制本，当天运气不错，和队友配合默契，打出了一些精彩的combo。跑团的形式也很喜欢，之后还玩了诡楼，2024年的目标是上血宴的车。', '/upload/C4D64FAF-CC61-4DC0-AFA9-848192965B86.png', '7.png', '2025-02-14 18:28');
INSERT INTO `t_gonggao` VALUES ('8', '剧本杀游戏分类及玩法解析', '剧本杀游戏分很多类，什么合作或者特殊规则都有。不管几人本，都分公开本和封闭本。公开本：所有人的剧本都写自己的人生剧情，自己的人物线，自己的情感。\n然后是时间线。然后是任务。这个本没法判断自己是不是凶手，所以可以全员说谎，例如六人都给死者下了毒，不知道哪个致命。底下会给你任务的\n公开本所有人的第一个任务都一样就是——————找出凶手，如果你自己是凶手，请隐藏。\n我玩的时候总是以为自己是凶手，撒一堆谎，然后推翻，发现自己不是，我就澄清。。。编的多离谱都行，我编的最离谱的自己是，明明就是个普通杀人案，我扯到了FBI和时空穿越。。。', '/upload/CA855AF3-5F64-4974-A952-90DDD1CFF3F2.png', '8.png', '2025-02-14 18:29');

-- ----------------------------
-- Table structure for `t_juben`
-- ----------------------------
DROP TABLE IF EXISTS `t_juben`;
CREATE TABLE `t_juben` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mingcheng` varchar(200) DEFAULT NULL,
  `jieshao` varchar(3000) DEFAULT NULL,
  `fujian` varchar(255) DEFAULT NULL,
  `beizhu` varchar(255) DEFAULT NULL,
  `del` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_juben
-- ----------------------------
INSERT INTO `t_juben` VALUES ('39', '密室逃脱', '一场精心策划的密室逃脱游戏，玩家需要在有限的时间内，通过解谜、寻找线索，成功逃离密室', '', '', 'no');
INSERT INTO `t_juben` VALUES ('40', '死亡通知单', '以悬疑小说为背景，玩家将扮演私家侦探，调查一系列离奇案件。剧本中充满了谜题和伏笔，玩家需要运用自己的推理能力，揭开真相，找出凶手', '', '', 'no');
INSERT INTO `t_juben` VALUES ('41', '暗杀名单', '玩家将扮演特工，执行一系列暗杀任务。剧本中融入了间谍、特工等元素，让玩家在紧张刺激的游戏氛围中，体验一把惊险刺激的特工生活', '', '', 'no');
INSERT INTO `t_juben` VALUES ('42', '时光旅人', '一场穿越时空的旅行，玩家将回到过去，改变自己的命运。剧本中融入了亲情、友情、爱情等元素，让玩家在游戏中感受到情感的温暖和力量。', '', '', 'no');

-- ----------------------------
-- Table structure for `t_liuyanban`
-- ----------------------------
DROP TABLE IF EXISTS `t_liuyanban`;
CREATE TABLE `t_liuyanban` (
  `id` int(55) NOT NULL AUTO_INCREMENT,
  `user_id` int(50) DEFAULT NULL,
  `neirong` varchar(200) DEFAULT NULL,
  `liuyanshi` varchar(2000) DEFAULT NULL,
  `huifu` varchar(50) DEFAULT NULL,
  `huifushi` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_liuyanban
-- ----------------------------
INSERT INTO `t_liuyanban` VALUES ('4', '153', '测试', '2025-02-14 21:30', '', '');
INSERT INTO `t_liuyanban` VALUES ('5', '153', '顶顶顶顶顶大大大', '2025-02-14 08:12', '', '');

-- ----------------------------
-- Table structure for `t_user`
-- ----------------------------
DROP TABLE IF EXISTS `t_user`;
CREATE TABLE `t_user` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` varchar(32) NOT NULL,
  `xingming` varchar(20) DEFAULT NULL,
  `xingbie` varchar(55) DEFAULT NULL,
  `nianling` int(11) DEFAULT NULL,
  `dizhi` varchar(30) DEFAULT NULL,
  `dianhua` varchar(11) DEFAULT NULL,
  `youxiang` varchar(50) DEFAULT NULL COMMENT 'ͷ',
  `fujian` varchar(55) DEFAULT NULL,
  `shijian` varchar(55) DEFAULT NULL,
  `del` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=155 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_user
-- ----------------------------
INSERT INTO `t_user` VALUES ('152', 'wanggang', '000000', '王刚', '男', '36', '计科', '13612345678', '58784454@qq.com', '', '', 'no');
INSERT INTO `t_user` VALUES ('153', 'liusan', '000000', '刘三', '男', '20', '国际贸易', '13545678989', 'liusan@163.com', '', '', 'no');
INSERT INTO `t_user` VALUES ('154', 'limei', '000000', '李梅', '女', '20', '计科', '13578451234', '485685@qq.com', '', '', 'no');

-- ----------------------------
-- Table structure for `t_xinwen`
-- ----------------------------
DROP TABLE IF EXISTS `t_xinwen`;
CREATE TABLE `t_xinwen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `biaoti` varchar(200) DEFAULT NULL,
  `neirong` varchar(3000) DEFAULT NULL,
  `fujian` varchar(255) DEFAULT NULL,
  `fujianYuan` varchar(255) DEFAULT NULL,
  `shijian` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_xinwen
-- ----------------------------
INSERT INTO `t_xinwen` VALUES ('1', '硬核推理剧本杀测评', '如今玩老本，都不会太难，只要不想太多就能盘出来，最后一幕实在毫无必要，一点都不合理。\n本来盘的好好的碰到一个贴脸玩家，整个体验感down到谷底，真特么恶心，对这个本印象也不好了，最后太好盘了，简直给一个线索锁一下凶，凶手就按在地上摩擦那种。当撒旦在犯罪很少见到的锤凶到死的本，简直摆在你面前说凶手就是他了，新的不能再新的推理本了。\n第一次拿到开天眼角色！全程没什么参与感，其他角色很难理解的事，在我的角色角度看来一目了然。凶案也很简单，不分析出手法都能另外个角度锁凶，全程无参与感。玩的话可以选年轻一代的。', '/upload/6762FB1E-39A1-4BC0-877A-8F901FF6DE6A.png', '1.png', '2025-02-14 18:31');
INSERT INTO `t_xinwen` VALUES ('2', '剧本杀新手必看：类型、黑话和小建议', '剧本杀新手们！如果你已经了解了一些基本的规则，那就让我们继续深入探索这个充满神秘和乐趣的世界吧！今天，我们将带你了解剧本杀的更多类型、黑话和一些实用的小建议。类型多样，满足不同口味\n情感本（沉浸本）：这类剧本以情感体验为主，剧情围绕亲情、友情、爱情等展开。通过演绎和信件等形式，玩家可以深入角色，体验角色的情感变化。适合情侣或暧昧期的朋友一起体验。硬核推理本：难度较高的推理剧本，需要玩家运用逻辑推理来破解案件。虽然适合有一定经验的玩家，但也有轻推理本供新手尝试。\n欢乐机制阵营本：这类剧本通常有一个游戏机制，玩家被分成几个阵营，通过完成各自的任务来达成胜利。适合喜欢轻松愉快氛围的玩家，尤其是新手。', '/upload/292F2FDA-95C5-4DBD-93B4-BE677180FE37.png', '9.png', '2025-02-14 18:31');
INSERT INTO `t_xinwen` VALUES ('3', '近期剧本杀推荐：值得一试的热门本', '最近玩了一些剧本杀，给大家分享一下我的体验和推荐。\n【苍崎】 情感本，故事完整，人物关系紧密，情感体验非常深刻。特别是家国情怀和爱情线，让人感动到哭。强烈推荐！\n【欲望派对】 变格微恐本，后面有一些反转和恐怖元素，适合喜欢刺激的小伙伴。\n【叫爸爸】欢乐本，游戏环节很长，组队很重要。如果大家放得开，笑声不断，体验感非常好。\n【DM又死了】推理本，适合新手玩家，剧情还可以，推理难度适中。', '/upload/6CB5EC39-DFAC-48B2-BDBD-47A681DA6114.png', '2.png', '2025-02-14 18:32');
INSERT INTO `t_xinwen` VALUES ('4', '剧本杀保姆级攻略，速速查收！', '最近玩了几款剧本杀，给大家分享一下我的感受。\n超级神作，必玩！《一座城2》：这座城系列真的是把“剧本”发挥到了极致，有种看电影的感觉。不仅仅是推理刑侦，还触及了城市的历史背景、权斗秘密和宗教哲理。游戏时间长达11小时，一步步揭开幕后阴谋，真的是让人欲罢不能。每个角色都有自己的故事，交织在一起，世界观和价值观的多线思辨部分也非常精彩。我觉得这是剧本立意最好的展开模式：不告诉你答案，而是教你如何思考。\n《红黑馆事件》：这个密室推理本真的是天花板级别！不能再透露更多细节了，反正就是很有趣。\n', '/upload/F2B560A1-B7A0-4A89-88CB-AE35BCDEA021.png', '5.png', '2025-02-14 18:34');

-- ----------------------------
-- Table structure for `t_yuyue`
-- ----------------------------
DROP TABLE IF EXISTS `t_yuyue`;
CREATE TABLE `t_yuyue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) DEFAULT NULL,
  `fangId` int(11) DEFAULT NULL,
  `zuoweiId` int(11) DEFAULT NULL,
  `riqi` varchar(255) DEFAULT NULL,
  `duan` varchar(50) DEFAULT NULL,
  `beizhu` varchar(255) DEFAULT NULL,
  `xingming` varchar(255) DEFAULT NULL,
  `dianhua` varchar(255) DEFAULT NULL,
  `feiyong` int(11) DEFAULT NULL,
  `fkzt` varchar(255) DEFAULT NULL,
  `fkfs` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_yuyue
-- ----------------------------
INSERT INTO `t_yuyue` VALUES ('2', '153', '34', '37', '2025-02-20', '08-10', '无', '刘三', '13645457878', '0', null, null);

-- ----------------------------
-- Table structure for `t_zuowei`
-- ----------------------------
DROP TABLE IF EXISTS `t_zuowei`;
CREATE TABLE `t_zuowei` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fangId` int(11) DEFAULT NULL,
  `bianhao` varchar(200) DEFAULT NULL,
  `del` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_zuowei
-- ----------------------------
INSERT INTO `t_zuowei` VALUES ('36', '34', '001', 'no');
INSERT INTO `t_zuowei` VALUES ('37', '34', '002', 'no');
INSERT INTO `t_zuowei` VALUES ('38', '34', '003', 'no');
INSERT INTO `t_zuowei` VALUES ('39', '34', '004', 'no');
INSERT INTO `t_zuowei` VALUES ('40', '37', '005', 'no');
INSERT INTO `t_zuowei` VALUES ('41', '37', '001', 'no');
INSERT INTO `t_zuowei` VALUES ('42', '37', '002', 'no');
INSERT INTO `t_zuowei` VALUES ('43', '37', '006', 'no');
INSERT INTO `t_zuowei` VALUES ('44', '38', '007', 'no');
INSERT INTO `t_zuowei` VALUES ('45', '38', '008', 'no');
INSERT INTO `t_zuowei` VALUES ('46', '38', '009', 'no');
INSERT INTO `t_zuowei` VALUES ('47', '38', '010', 'no');
INSERT INTO `t_zuowei` VALUES ('48', '38', '011', 'no');
INSERT INTO `t_zuowei` VALUES ('49', '39', '012', 'no');
